#include <reg52.h>//ͷ�ļ�
#include <math.h>
#define uchar unsigned char//�궨��
#define uint unsigned int

sbit ds=P1^0;//ds18b20�¶ȴ������ӿ�
sbit seg1=P2^0;
sbit seg2=P2^1;
sbit seg3=P2^2;
sbit seg4=P2^3;

int wendu,t,temp;

uchar code SEG[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf};

void delay(uint z)                        //��ʱ����
{
    uint x,y;
    for(x=z;x>0;x--)
        for(y=100;y>0;y--);
}

void dsreset()                     //ds18b20��ʼ��
{
    uint i;
    ds=0;
	delay(1);
    ds=1;
    i=1;
    while(i>0)i--;
}
bit tempreadbit(void)                  //��һλ
{
    uint i;
    bit dat;
    ds=0;i++;
    ds=1;i++;i++;
    dat=ds;
    i=5;while(i>0)i--;
    return(dat);
}
uchar tempread()                     //��ȡ�¶�
{
    uchar i,j,dat;
    dat=0;
    for(i=1;i<=8;i++)
    {
        j=tempreadbit();
        dat=(j<<7)|(dat>>1);
    }
    return(dat);
}
void tempwritebyte(uchar dat)              //дһ���ֽ�
{
    uint i;
    uchar j;
    bit testb;
    for(j=1;j<=8;j++)
    {
        testb=dat&0x01;
        dat=dat>>1;
        if(testb)
        {
            ds=0;
            i++;
			i++;
            ds=1;
            i=5;
			while(i>0)i--;
        }
        else
        {
            ds=0;
            i=5;
			while(i>0)i--;
            ds=1;
            i++;i++;
        }
    }
}

void tempchange()                      //�¶�ת��
{
    dsreset();
    delay(1);
    tempwritebyte(0xcc);
    tempwritebyte(0x44);				//�����¶�ת��
}

uint get_temp()                         //��ȡ�¶�
{
    bit tflag;
	uchar a,b;
    dsreset();
    delay(1);
    tempwritebyte(0xcc);				//����ROM
    tempwritebyte(0xbe);				//���¶�
    a=tempread();						//��ȡ��8λ
    b=tempread();						//��ȡ��8λ
    temp=b;
    temp<<=8;
    temp=temp|a;

	if (b >= 8) {
		temp = ~temp+1 ;
		tflag = 1;
	} else {
		tflag = 0;
	}
	if (tflag == 1)
		temp = temp * 0.625 * (-1)-0.5;
	if (tflag == 0)
		temp = temp * 0.625;

    return temp;
    
}

void display(int temp1)
{
    int temp2;
	temp2=abs(temp1);
	if(temp1>=0)
	{
	  P0=0xff;
	  seg1=0;
	  P0=SEG[temp2/1000];
	  delay(1);
	  seg1=1;
	}
	else {
	    P0=0xff;
	    seg1=0;
		P0 = 0xbf;
		delay(1);
		seg1=1;
	}

    P0=0xff;//����
    seg2=0;//�򿪵ڶ�������ܵĶ�ѡ
    P0=SEG[temp2%1000/100];
    delay(1);
    seg2=1;
    
    P0=0xff;
    seg3=0;
    P0=SEG[temp2%100/10]&0x7f;
    delay(1);
    seg3=1;
    
    P0=0xff;
    seg4=0;
    P0=SEG[temp2%10];
    delay(1);
    seg4=1;
}

void main()
{
    while(1)
    {
        tempchange();
        t=get_temp();
        if(t>=-550&&t<=1280)  //�¶ȺϷ���Χ�����������Χ����û�л�ȡ�����ʵ�ֵ
        {
            wendu=t;
        }
		delay(1);
        display(wendu);
    
    }
}
